import { Button } from "react-bootstrap"
import "./Aploadprofile.css"
export const Aploadprofile=()=>{
    return(
        <>
        <form className="fo">
            <input className="inpu" type="file" />
            <Button className="mt-1" variant="outline-dark">save</Button>
        </form>
        
        </>
    )
}
export default Aploadprofile