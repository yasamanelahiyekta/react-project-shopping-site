
import React, { useState } from 'react'
import { useDispatch } from 'react-redux';
import { v4 as uuidv4 } from 'uuid';
import "./cart.css"
import { Badge, Button, CloseButton, Col, Container, Row } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { number } from '../../Action';
const Cart = () => {
    const [flag, setFlag] = useState(false)
    const toast = () => {
        return toast('first you must login', {
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "light",
        });
    }
    const navigate = useNavigate()
    const token = localStorage.getItem("token")
    console.log(token);
    const data = JSON.parse(localStorage.getItem("cart"))
    console.log(data);
    const price = data.reduce((x, item) => {
        return x + item.price
    }, 0)
    localStorage.setItem("price", JSON.stringify(price))
    console.log(price);
    const dispatch = useDispatch()
    const help = {}
    data.map(item => {
        help[item._id] = []
    })
    data.map(item => {
        help[item._id] = [...help[item._id], item]
    })
    const list = []
    Object.entries(help).map(([key, value]) => list.push({ "product": key, "qty": value.length })
    )
    localStorage.setItem("list", JSON.stringify(list))
    return (
        <div>
            { !data.length ? <div>
                <h1>cart is empty</h1>
            </div> : Object.entries(help).map(([key, value]) => (
                <div key={ uuidv4() } className='bo' >
                    <Container>
                        <Row className='mb-5'>
                            <Col xs={ { offset: "11", xs: "1" } }>
                                <Button onClick={ () => {
                                    const data2 = data.filter(item => item._id !== key)
                                    localStorage.setItem("cart", JSON.stringify(data2))
                                    dispatch(number((value.length) * -1));
                                    setFlag(l => !l)

                                } } bg='danger'  ><CloseButton />Delete</Button>
                            </Col>
                        </Row>
                    </Container>
                    <Container>
                        <div className='main' >
                            <Row>

                                <Col xs="3" className='c' ><img src={ `${value[0].image}` } /></Col>
                                <Col xs="3" className='c' >{ value[0].price }</Col>
                                <Col xs="3" className='c' >{ value[0].name }</Col>
                                <Col xs="3" className='c' > <div className='ne'>

                                    <div className='en'>
                                        <Button size='sm' onClick={ () => {
                                            setFlag(l => !l)

                                            const data2 = data.filter(item => item._id !== key)
                                            const data3 = data.filter(item => item._id == key)
                                            data3.shift()
                                            const data4 = data2.concat(data3)
                                            localStorage.setItem("cart", JSON.stringify(data4))
                                            dispatch(number(-1))
                                            // value[0]._id == key && value.shift()
                                            // console.log(value, "val");
                                            // console.log(data.filter(item => item._id==key &&), "data");

                                        }

                                        } >-</Button>
                                        <span>
                                            { value.length }
                                        </span>
                                        <Button size='sm' variant={ value.length == value[0].countInStock ? "secondary" : "info" } onClick={ () => {
                                            setFlag(l => !l)
                                            value.length < value[0].countInStock && value[0]._id == key && data.push(value[0]) && dispatch(number(1))
                                            localStorage.setItem("cart", JSON.stringify(data))
                                        } } >+</Button>
                                    </div>
                                    <div>{ value.length == value[0].countInStock ? <p style={ { color: 'gray' } } >
                                        not exist
                                    </p> : "" }</div>
                                </div>
                                </Col>
                            </Row>
                        </div>
                    </Container>

                </div>
            )) }
            { !data.length ? "" :
                <>
                    <Badge bg='dark' >{ price ? <span>{ price } $</span> : "" }</Badge><br />
                    <Button variant='outline-dark' className='mt-4' onClick={ () => {
                        token ? navigate("/Adrress") : Swal.fire({
                            title: `😟
                    first you must login`,
                            showDenyButton: false,
                            showCancelButton: true,
                            confirmButtonText: 'ok',
                        }).then((result) => {
                            /* Read more about isConfirmed, isDenied below */
                            if (result.isConfirmed) {
                                navigate("/Login")
                            }
                        })
                    } } >next</Button>

                </>
            }
        </div>
    )
}

export default Cart

